var distance = 0; // set distance = width picture 200pxs
const Stage = document.getElementById('stage');

$('#next').click(() => {
    if (distance == -1000)
    {
        distance = -1000;
    }
    else {
        distance -= 200;
        Stage.style.transform =  `translateX(${distance}px)`;
    }
});

$('#prev').click(() => {
    if (distance == 0) {
        distance = 0;
    }
    else {
        distance += 200;
        Stage.style.transform =  `translateX(${distance}px)`;
    }
});

