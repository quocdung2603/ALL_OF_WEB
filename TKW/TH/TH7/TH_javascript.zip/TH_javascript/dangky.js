function kiemtrathongtin()
        {
            var hoten=document.getElementById("hoten");
            if(hoten.value=="")
            {
                alert("Vui lòng nhập lại họ tên.");
                hoten.focus();
                return false;
            }
            var nam=document.getElementById("nam");
            if (nam.value==""){
                alert("Hãy điền Năm sinh.");
                nam.focus();
                return false;
            }
            if (isNaN(nam.value)==true){
                alert("Năm sinh phải là số.");
                nam.value="";
                nam.focus();
                return false;
            }
            var email=document.getElementById("email");
            re=/\w+@\w+\.\w+/;
            if (email.value==""){
                alert("Bạn chưa nhập Email.") ;
                email.focus();
                return false;
            }
            else
                if(re.test(email.value)==false){
                    alert("Email không đúng định dạng!");
                    email.focus();
                    return false;
                }
            var tendangnhap=document.getElementById("tendangnhap");
            if(tendangnhap.value=="")
            {
                alert("Hãy nhập tên đăng nhập.")
                tendangnhap.focus();
                return false;
            }
            var matkhau=document.getElementById("matkhau");
            if(matkhau.value=="")
            {
                alert("Hãy nhập mật khẩu.");
                matkhau.focus();
                return false;
            }
            var nhaplaimatkhau=document.getElementById("nhaplaimatkhau");
            if(nhaplaimatkhau.value=="")
            {
                alert("Hãy nhập lại mật khẩu.");
                nhaplaimatkhau.focus();
                return false;
            }
            if(nhaplaimatkhau.value != matkhau.value)
            {
                alert("Mật khẩu không trùng khớp.");
                nhaplaimatkhau.focus();
                return false;
            }
    
            var sodienthoai=document.getElementById("sodienthoai");
            if(sodienthoai.value=="")
            {
                alert(" Hãy nhập số điện thoại");
                sodienthoai.focus();
                return false;
            }
            if(isNaN(sodienthoai.value)==true)
            {
                alert("Số điện thoại phải toàn là số.");
                sodienthoai.value="";
                sodienthoai.focus();
                return false;
            }
            var diachi=document.getElementById("diachi");
            if(diachi.value=="")
            {
                alert("Hãy nhập địa chỉ.");
                diachi.focus();
                return false;
            }
            alert("Đăng ký thành công! Xin chúc mừng.");
            return true;
        }